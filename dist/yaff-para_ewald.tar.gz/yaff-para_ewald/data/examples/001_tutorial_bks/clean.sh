#!/bin/bash

rm -v */*.h5 */*.png */*.chk */traj*.xyz
