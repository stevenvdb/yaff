#!/bin/bash
rm -v traj.xyz output.h5 energies.png temp_dist.png
